import { Hono } from 'hono'
import { serveStatic } from 'hono/cloudflare-workers'

const app = new Hono()

app.use('/static/*', serveStatic({ root: './' }))

app.get('/', (c) => {
  return c.html(`<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Bisa Cafés Especiais – Apucarana, PR</title>
  <meta name="description" content="Bisa Cafés Especiais – Os melhores cafés especiais de Apucarana, PR. Venha nos visitar!" />
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet" />
  <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet" />
  <style>
    /* ===== CSS VARIABLES ===== */
    :root {
      --bg-primary: #fdf8f3;
      --bg-secondary: #f5ede1;
      --bg-card: #ffffff;
      --bg-nav: rgba(253, 248, 243, 0.95);
      --text-primary: #2c1810;
      --text-secondary: #6b4226;
      --text-muted: #9c7150;
      --accent-dark: #3e1f10;
      --accent-mid: #7b4226;
      --accent-light: #c07850;
      --accent-gold: #d4a052;
      --border: #e8d5c0;
      --shadow: rgba(62, 31, 16, 0.08);
      --shadow-md: rgba(62, 31, 16, 0.15);
      --shadow-lg: rgba(62, 31, 16, 0.22);
      --hero-overlay: rgba(30, 12, 5, 0.50);
      --status-open: #2e7d32;
      --status-closed: #c62828;
      --status-soon: #e65100;
    }

    [data-theme="dark"] {
      --bg-primary: #1a0d07;
      --bg-secondary: #231108;
      --bg-card: #2c1810;
      --bg-nav: rgba(26, 13, 7, 0.97);
      --text-primary: #f5e6d3;
      --text-secondary: #d4a87a;
      --text-muted: #a07050;
      --accent-dark: #f5e6d3;
      --accent-mid: #e8c49a;
      --accent-light: #d4a87a;
      --accent-gold: #e8b860;
      --border: #4a2c1a;
      --shadow: rgba(0, 0, 0, 0.3);
      --shadow-md: rgba(0, 0, 0, 0.45);
      --shadow-lg: rgba(0, 0, 0, 0.60);
      --hero-overlay: rgba(10, 4, 1, 0.65);
      --status-open: #66bb6a;
      --status-closed: #ef5350;
      --status-soon: #ffa726;
    }

    /* ===== RESET & BASE ===== */
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    html { scroll-behavior: smooth; }
    body {
      font-family: 'Inter', sans-serif;
      background: var(--bg-primary);
      color: var(--text-primary);
      transition: background 0.3s, color 0.3s;
      line-height: 1.6;
    }
    img { max-width: 100%; display: block; }
    a { text-decoration: none; color: inherit; }

    /* ===== SCROLLBAR ===== */
    ::-webkit-scrollbar { width: 6px; }
    ::-webkit-scrollbar-track { background: var(--bg-secondary); }
    ::-webkit-scrollbar-thumb { background: var(--accent-light); border-radius: 3px; }

    /* ===== NAVBAR ===== */
    .navbar {
      position: fixed; top: 0; left: 0; right: 0; z-index: 1000;
      background: var(--bg-nav);
      backdrop-filter: blur(12px);
      border-bottom: 1px solid var(--border);
      padding: 0 2rem;
      height: 70px;
      display: flex; align-items: center; justify-content: space-between;
      box-shadow: 0 2px 20px var(--shadow);
      transition: background 0.3s, border-color 0.3s;
    }
    .navbar-brand {
      display: flex; align-items: center; gap: 12px;
    }
    .navbar-logo {
      width: 44px; height: 44px;
      background: linear-gradient(135deg, var(--accent-mid), var(--accent-dark));
      border-radius: 50%;
      display: flex; align-items: center; justify-content: center;
      color: #fff; font-size: 1.2rem;
      box-shadow: 0 2px 10px var(--shadow-md);
    }
    .navbar-title {
      font-family: 'Playfair Display', serif;
      font-size: 1.15rem;
      font-weight: 700;
      color: var(--text-primary);
      line-height: 1.2;
    }
    .navbar-subtitle {
      font-size: 0.68rem;
      color: var(--text-muted);
      letter-spacing: 0.12em;
      text-transform: uppercase;
    }
    .navbar-links {
      display: flex; align-items: center; gap: 0.2rem;
      list-style: none;
    }
    .navbar-links a {
      padding: 8px 14px;
      border-radius: 8px;
      font-size: 0.88rem;
      font-weight: 500;
      color: var(--text-secondary);
      transition: background 0.2s, color 0.2s;
    }
    .navbar-links a:hover {
      background: var(--bg-secondary);
      color: var(--accent-mid);
    }
    .navbar-actions {
      display: flex; align-items: center; gap: 10px;
    }
    .theme-toggle {
      width: 40px; height: 40px;
      border-radius: 10px;
      border: 1px solid var(--border);
      background: var(--bg-secondary);
      color: var(--text-secondary);
      cursor: pointer;
      display: flex; align-items: center; justify-content: center;
      font-size: 1rem;
      transition: all 0.2s;
    }
    .theme-toggle:hover {
      background: var(--accent-mid);
      color: #fff;
      border-color: var(--accent-mid);
    }
    .hamburger {
      display: none;
      flex-direction: column; gap: 5px;
      cursor: pointer; padding: 6px;
      border: none; background: none;
    }
    .hamburger span {
      display: block; width: 24px; height: 2px;
      background: var(--text-primary);
      border-radius: 2px;
      transition: all 0.3s;
    }
    .mobile-menu {
      display: none;
      position: fixed; top: 70px; left: 0; right: 0;
      background: var(--bg-nav);
      backdrop-filter: blur(12px);
      border-bottom: 1px solid var(--border);
      padding: 1rem;
      z-index: 999;
      flex-direction: column; gap: 0.3rem;
    }
    .mobile-menu.open { display: flex; }
    .mobile-menu a {
      padding: 12px 16px;
      border-radius: 8px;
      font-size: 0.95rem;
      font-weight: 500;
      color: var(--text-secondary);
      display: flex; align-items: center; gap: 10px;
    }
    .mobile-menu a:hover { background: var(--bg-secondary); color: var(--accent-mid); }

    /* ===== HERO ===== */
    .hero {
      min-height: 100vh;
      background:
        linear-gradient(var(--hero-overlay), var(--hero-overlay)),
        url('https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=1600&q=80') center/cover no-repeat;
      display: flex; align-items: center; justify-content: center;
      text-align: center;
      padding: 6rem 2rem 4rem;
      position: relative;
    }
    .hero-content { max-width: 700px; }
    .hero-badge {
      display: inline-flex; align-items: center; gap: 8px;
      background: rgba(255,255,255,0.12);
      backdrop-filter: blur(8px);
      border: 1px solid rgba(255,255,255,0.25);
      border-radius: 50px;
      padding: 6px 18px;
      font-size: 0.8rem;
      color: #f5e6c8;
      letter-spacing: 0.1em;
      text-transform: uppercase;
      margin-bottom: 1.5rem;
    }
    .hero h1 {
      font-family: 'Playfair Display', serif;
      font-size: clamp(2.8rem, 7vw, 5rem);
      font-weight: 700;
      color: #fff;
      line-height: 1.1;
      margin-bottom: 1rem;
      text-shadow: 0 2px 20px rgba(0,0,0,0.3);
    }
    .hero h1 span { color: var(--accent-gold); }
    .hero p {
      font-size: 1.15rem;
      color: rgba(255,255,255,0.85);
      margin-bottom: 2.5rem;
      font-weight: 300;
      max-width: 500px;
      margin-left: auto;
      margin-right: auto;
    }
    .hero-cta {
      display: flex; gap: 1rem; justify-content: center; flex-wrap: wrap;
    }
    .btn-primary {
      display: inline-flex; align-items: center; gap: 8px;
      background: linear-gradient(135deg, var(--accent-mid), var(--accent-dark));
      color: #fff;
      padding: 14px 32px;
      border-radius: 50px;
      font-size: 0.95rem;
      font-weight: 600;
      letter-spacing: 0.02em;
      transition: all 0.3s;
      box-shadow: 0 4px 20px rgba(62,31,16,0.4);
      border: none; cursor: pointer;
    }
    .btn-primary:hover {
      transform: translateY(-2px);
      box-shadow: 0 8px 30px rgba(62,31,16,0.5);
    }
    .btn-outline {
      display: inline-flex; align-items: center; gap: 8px;
      background: transparent;
      color: #fff;
      padding: 14px 32px;
      border-radius: 50px;
      font-size: 0.95rem;
      font-weight: 600;
      border: 2px solid rgba(255,255,255,0.5);
      transition: all 0.3s;
      cursor: pointer;
      text-decoration: none;
    }
    .btn-outline:hover {
      background: rgba(255,255,255,0.15);
      border-color: rgba(255,255,255,0.8);
      transform: translateY(-2px);
    }
    .hero-scroll {
      position: absolute; bottom: 2.5rem; left: 50%; transform: translateX(-50%);
      display: flex; flex-direction: column; align-items: center; gap: 8px;
      color: rgba(255,255,255,0.6); font-size: 0.75rem; letter-spacing: 0.1em;
      text-transform: uppercase;
      animation: bounce 2s infinite;
    }
    @keyframes bounce {
      0%, 100% { transform: translateX(-50%) translateY(0); }
      50% { transform: translateX(-50%) translateY(-8px); }
    }

    /* ===== STATUS BAR ===== */
    .status-bar {
      background: var(--bg-secondary);
      border-bottom: 1px solid var(--border);
      padding: 12px 2rem;
      display: flex; align-items: center; justify-content: center;
      gap: 2rem; flex-wrap: wrap;
      font-size: 0.88rem;
    }
    .status-indicator {
      display: flex; align-items: center; gap: 8px;
      font-weight: 600;
    }
    .status-dot {
      width: 10px; height: 10px; border-radius: 50%;
      animation: pulse 2s infinite;
    }
    .status-dot.open { background: var(--status-open); }
    .status-dot.closed { background: var(--status-closed); animation: none; }
    .status-dot.soon { background: var(--status-soon); }
    @keyframes pulse {
      0%, 100% { opacity: 1; transform: scale(1); }
      50% { opacity: 0.6; transform: scale(1.3); }
    }
    .status-text.open { color: var(--status-open); }
    .status-text.closed { color: var(--status-closed); }
    .status-text.soon { color: var(--status-soon); }
    .status-info {
      display: flex; align-items: center; gap: 6px;
      color: var(--text-muted);
    }
    .status-clock {
      font-weight: 700;
      color: var(--text-primary);
      font-size: 1rem;
      letter-spacing: 0.05em;
    }

    /* ===== SECTIONS ===== */
    section { padding: 5rem 2rem; }
    .section-inner { max-width: 1100px; margin: 0 auto; }
    .section-label {
      font-size: 0.78rem;
      letter-spacing: 0.18em;
      text-transform: uppercase;
      color: var(--accent-light);
      font-weight: 600;
      margin-bottom: 0.5rem;
    }
    .section-title {
      font-family: 'Playfair Display', serif;
      font-size: clamp(1.9rem, 4vw, 2.8rem);
      font-weight: 700;
      color: var(--text-primary);
      line-height: 1.25;
      margin-bottom: 0.8rem;
    }
    .section-subtitle {
      font-size: 1rem;
      color: var(--text-muted);
      max-width: 550px;
      margin-bottom: 3rem;
    }
    .divider {
      width: 60px; height: 3px;
      background: linear-gradient(90deg, var(--accent-mid), var(--accent-gold));
      border-radius: 2px;
      margin: 1rem 0 2rem;
    }

    /* ===== ABOUT ===== */
    .about-grid {
      display: grid; grid-template-columns: 1fr 1fr;
      gap: 4rem; align-items: center;
    }
    .about-image-wrapper {
      position: relative;
    }
    .about-image {
      width: 100%; height: 460px; object-fit: cover;
      border-radius: 20px;
      box-shadow: 0 20px 60px var(--shadow-lg);
    }
    .about-image-badge {
      position: absolute; bottom: -20px; right: -20px;
      background: linear-gradient(135deg, var(--accent-mid), var(--accent-dark));
      color: #fff;
      border-radius: 16px;
      padding: 16px 24px;
      text-align: center;
      box-shadow: 0 8px 30px var(--shadow-lg);
    }
    .about-image-badge .number {
      font-family: 'Playfair Display', serif;
      font-size: 2.4rem;
      font-weight: 700;
      line-height: 1;
    }
    .about-image-badge .label { font-size: 0.75rem; opacity: 0.85; margin-top: 4px; }
    .about-features {
      display: grid; grid-template-columns: 1fr 1fr;
      gap: 1.2rem; margin-top: 2rem;
    }
    .about-feature {
      display: flex; align-items: flex-start; gap: 12px;
      padding: 14px;
      background: var(--bg-secondary);
      border-radius: 12px;
      border: 1px solid var(--border);
    }
    .about-feature-icon {
      width: 36px; height: 36px; min-width: 36px;
      background: linear-gradient(135deg, var(--accent-mid), var(--accent-dark));
      border-radius: 10px;
      display: flex; align-items: center; justify-content: center;
      color: #fff; font-size: 0.9rem;
    }
    .about-feature h4 { font-size: 0.88rem; font-weight: 600; color: var(--text-primary); }
    .about-feature p { font-size: 0.78rem; color: var(--text-muted); margin-top: 2px; }

    /* ===== MENU ===== */
    .menu-section { background: var(--bg-secondary); }
    .menu-tabs {
      display: flex; gap: 0.5rem; flex-wrap: wrap;
      margin-bottom: 2.5rem;
    }
    .menu-tab {
      padding: 10px 22px;
      border-radius: 50px;
      font-size: 0.88rem; font-weight: 600;
      border: 2px solid var(--border);
      background: var(--bg-card);
      color: var(--text-secondary);
      cursor: pointer; transition: all 0.25s;
      display: flex; align-items: center; gap: 6px;
    }
    .menu-tab.active, .menu-tab:hover {
      background: linear-gradient(135deg, var(--accent-mid), var(--accent-dark));
      color: #fff; border-color: transparent;
      box-shadow: 0 4px 15px var(--shadow-md);
    }
    .menu-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(290px, 1fr));
      gap: 1.5rem;
    }
    .menu-category { display: none; }
    .menu-category.active { display: contents; }
    .menu-card {
      background: var(--bg-card);
      border-radius: 16px;
      border: 1px solid var(--border);
      overflow: hidden;
      transition: all 0.3s;
      box-shadow: 0 2px 10px var(--shadow);
    }
    .menu-card:hover {
      transform: translateY(-4px);
      box-shadow: 0 12px 40px var(--shadow-md);
      border-color: var(--accent-light);
    }
    .menu-card-img {
      width: 100%; height: 180px;
      object-fit: cover;
      background: var(--bg-secondary);
      display: flex; align-items: center; justify-content: center;
      font-size: 3rem;
    }
    .menu-card-body { padding: 1.2rem; }
    .menu-card-tag {
      display: inline-block;
      font-size: 0.7rem; font-weight: 600;
      letter-spacing: 0.08em; text-transform: uppercase;
      color: var(--accent-light);
      background: var(--bg-secondary);
      padding: 3px 10px; border-radius: 50px;
      margin-bottom: 0.6rem;
      border: 1px solid var(--border);
    }
    .menu-card h3 {
      font-family: 'Playfair Display', serif;
      font-size: 1.1rem; font-weight: 600;
      color: var(--text-primary); margin-bottom: 0.4rem;
    }
    .menu-card p {
      font-size: 0.83rem; color: var(--text-muted); line-height: 1.55;
      margin-bottom: 1rem;
    }
    .menu-card-footer {
      display: flex; align-items: center; justify-content: space-between;
    }
    .menu-price {
      font-size: 1.15rem; font-weight: 700;
      color: var(--accent-mid);
    }
    .menu-badge {
      font-size: 0.72rem; font-weight: 600;
      padding: 3px 10px; border-radius: 50px;
      background: linear-gradient(135deg, #d4a052, #b8861e);
      color: #fff;
    }

    /* ===== HOURS ===== */
    .hours-grid {
      display: grid; grid-template-columns: 1fr 1fr;
      gap: 2.5rem; align-items: start;
    }
    .hours-table {
      background: var(--bg-card);
      border: 1px solid var(--border);
      border-radius: 20px;
      overflow: hidden;
      box-shadow: 0 4px 20px var(--shadow);
    }
    .hours-table-header {
      background: linear-gradient(135deg, var(--accent-mid), var(--accent-dark));
      padding: 1.2rem 1.5rem;
      color: #fff;
      display: flex; align-items: center; gap: 10px;
      font-weight: 600; font-size: 0.95rem;
    }
    .hours-row {
      display: flex; align-items: center; justify-content: space-between;
      padding: 14px 1.5rem;
      border-bottom: 1px solid var(--border);
      font-size: 0.9rem;
      transition: background 0.2s;
    }
    .hours-row:last-child { border-bottom: none; }
    .hours-row:hover { background: var(--bg-secondary); }
    .hours-row.today {
      background: linear-gradient(90deg, var(--bg-secondary), transparent);
      font-weight: 600;
    }
    .hours-day { color: var(--text-secondary); }
    .hours-row.today .hours-day { color: var(--accent-mid); }
    .hours-time { color: var(--text-primary); font-weight: 500; }
    .hours-closed { color: var(--text-muted); font-style: italic; }
    .today-badge {
      font-size: 0.65rem; font-weight: 700; letter-spacing: 0.08em;
      background: linear-gradient(135deg, var(--accent-mid), var(--accent-dark));
      color: #fff; padding: 2px 8px; border-radius: 50px;
      text-transform: uppercase; margin-left: 8px;
    }
    .hours-info-cards {
      display: flex; flex-direction: column; gap: 1.2rem;
    }
    .hours-info-card {
      background: var(--bg-card);
      border: 1px solid var(--border);
      border-radius: 16px;
      padding: 1.4rem;
      display: flex; align-items: flex-start; gap: 14px;
      box-shadow: 0 2px 10px var(--shadow);
      transition: all 0.3s;
    }
    .hours-info-card:hover { transform: translateX(4px); border-color: var(--accent-light); }
    .hours-info-icon {
      width: 44px; height: 44px; min-width: 44px;
      background: linear-gradient(135deg, var(--accent-mid), var(--accent-dark));
      border-radius: 12px;
      display: flex; align-items: center; justify-content: center;
      color: #fff; font-size: 1.1rem;
    }
    .hours-info-card h4 { font-size: 0.9rem; font-weight: 600; color: var(--text-primary); margin-bottom: 2px; }
    .hours-info-card p { font-size: 0.83rem; color: var(--text-muted); line-height: 1.5; }
    .hours-info-card a { color: var(--accent-light); }
    .hours-info-card a:hover { color: var(--accent-mid); }

    /* ===== GALLERY ===== */
    .gallery-grid {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      grid-template-rows: repeat(2, 220px);
      gap: 12px;
    }
    .gallery-item {
      border-radius: 14px; overflow: hidden;
      position: relative; cursor: pointer;
    }
    .gallery-item:first-child {
      grid-row: 1 / 3; grid-column: 1;
    }
    .gallery-item img {
      width: 100%; height: 100%;
      object-fit: cover;
      transition: transform 0.5s;
    }
    .gallery-item:hover img { transform: scale(1.06); }
    .gallery-overlay {
      position: absolute; inset: 0;
      background: linear-gradient(transparent 50%, rgba(20,8,3,0.7));
      opacity: 0; transition: opacity 0.3s;
      display: flex; align-items: flex-end;
      padding: 1rem;
    }
    .gallery-item:hover .gallery-overlay { opacity: 1; }
    .gallery-overlay span {
      color: #fff; font-size: 0.85rem; font-weight: 500;
    }

    /* ===== MAP / CONTACT ===== */
    .contact-section { background: var(--bg-secondary); }
    .contact-grid {
      display: grid; grid-template-columns: 1fr 1fr;
      gap: 3rem; align-items: start;
    }
    .contact-info { display: flex; flex-direction: column; gap: 1.2rem; }
    .contact-item {
      display: flex; align-items: flex-start; gap: 14px;
      padding: 1.2rem;
      background: var(--bg-card);
      border: 1px solid var(--border);
      border-radius: 14px;
      transition: all 0.3s;
    }
    .contact-item:hover { transform: translateX(4px); border-color: var(--accent-light); }
    .contact-icon {
      width: 42px; height: 42px; min-width: 42px;
      background: linear-gradient(135deg, var(--accent-mid), var(--accent-dark));
      border-radius: 12px;
      display: flex; align-items: center; justify-content: center;
      color: #fff; font-size: 1rem;
    }
    .contact-item h4 { font-size: 0.88rem; font-weight: 600; color: var(--text-primary); margin-bottom: 2px; }
    .contact-item p { font-size: 0.83rem; color: var(--text-muted); line-height: 1.5; }
    .contact-item a { color: var(--accent-light); }
    .contact-item a:hover { color: var(--accent-mid); }
    .map-container {
      border-radius: 20px; overflow: hidden;
      box-shadow: 0 8px 40px var(--shadow-lg);
      border: 1px solid var(--border);
      height: 380px;
      background: var(--bg-secondary);
      position: relative;
    }
    .map-container iframe {
      width: 100%; height: 100%; border: none; display: block;
    }
    .map-placeholder {
      width: 100%; height: 100%;
      display: flex; flex-direction: column; align-items: center; justify-content: center;
      gap: 1rem; color: var(--text-muted);
    }
    .map-placeholder i { font-size: 3rem; color: var(--accent-light); }
    .map-placeholder p { font-size: 0.9rem; text-align: center; }
    .map-cta {
      display: inline-flex; align-items: center; gap: 8px;
      background: linear-gradient(135deg, var(--accent-mid), var(--accent-dark));
      color: #fff; padding: 12px 24px; border-radius: 50px;
      font-size: 0.88rem; font-weight: 600;
      transition: all 0.3s;
    }
    .map-cta:hover { transform: translateY(-2px); box-shadow: 0 6px 20px var(--shadow-md); }

    /* ===== SOCIAL BANNER ===== */
    .social-banner {
      background: linear-gradient(135deg, var(--accent-dark), var(--accent-mid));
      padding: 3.5rem 2rem; text-align: center;
    }
    .social-banner h2 {
      font-family: 'Playfair Display', serif;
      font-size: 2rem; color: #fff;
      margin-bottom: 0.5rem;
    }
    .social-banner p { color: rgba(255,255,255,0.8); margin-bottom: 2rem; }
    .social-links { display: flex; gap: 1rem; justify-content: center; flex-wrap: wrap; }
    .social-link {
      display: inline-flex; align-items: center; gap: 8px;
      padding: 12px 24px;
      border-radius: 50px;
      background: rgba(255,255,255,0.15);
      color: #fff;
      font-size: 0.88rem; font-weight: 600;
      border: 1px solid rgba(255,255,255,0.3);
      transition: all 0.3s;
    }
    .social-link:hover { background: rgba(255,255,255,0.28); transform: translateY(-2px); }

    /* ===== FOOTER ===== */
    footer {
      background: var(--accent-dark);
      padding: 2.5rem 2rem 1.5rem;
      color: rgba(255,255,255,0.7);
    }
    .footer-inner {
      max-width: 1100px; margin: 0 auto;
      display: flex; align-items: center; justify-content: space-between;
      flex-wrap: wrap; gap: 1rem;
    }
    .footer-brand {
      font-family: 'Playfair Display', serif;
      font-size: 1.2rem; color: #fff; font-weight: 700;
    }
    .footer-brand span { color: var(--accent-gold); }
    .footer-copy { font-size: 0.8rem; text-align: center; }
    .footer-links { display: flex; gap: 1.5rem; }
    .footer-links a { font-size: 0.82rem; color: rgba(255,255,255,0.55); transition: color 0.2s; }
    .footer-links a:hover { color: var(--accent-gold); }

    /* ===== FLOATING WHATSAPP ===== */
    .whatsapp-float {
      position: fixed; bottom: 2rem; right: 2rem; z-index: 900;
      width: 56px; height: 56px;
      background: #25D366;
      border-radius: 50%;
      display: flex; align-items: center; justify-content: center;
      color: #fff; font-size: 1.6rem;
      box-shadow: 0 4px 20px rgba(37,211,102,0.45);
      transition: all 0.3s;
      cursor: pointer;
    }
    .whatsapp-float:hover { transform: scale(1.1); box-shadow: 0 8px 30px rgba(37,211,102,0.55); }

    /* ===== RESPONSIVE ===== */
    @media (max-width: 768px) {
      .navbar-links { display: none; }
      .hamburger { display: flex; }
      .about-grid, .hours-grid, .contact-grid { grid-template-columns: 1fr; }
      .about-image { height: 280px; }
      .about-image-badge { right: 0; bottom: -15px; }
      .about-features { grid-template-columns: 1fr; }
      .gallery-grid { grid-template-columns: 1fr 1fr; grid-template-rows: auto; }
      .gallery-item:first-child { grid-row: auto; grid-column: auto; }
      .hero h1 { font-size: 2.5rem; }
      section { padding: 3.5rem 1.2rem; }
      .status-bar { flex-direction: column; gap: 0.8rem; }
      .footer-inner { flex-direction: column; text-align: center; }
    }
    @media (max-width: 480px) {
      .navbar { padding: 0 1.2rem; }
      .gallery-grid { grid-template-columns: 1fr; }
      .hero { padding: 5rem 1.2rem 4rem; }
    }
  </style>
</head>
<body>

<!-- NAVBAR -->
<nav class="navbar">
  <div class="navbar-brand">
    <div class="navbar-logo"><i class="fas fa-mug-hot"></i></div>
    <div>
      <div class="navbar-title">Bisa Cafés</div>
      <div class="navbar-subtitle">Especiais · Apucarana</div>
    </div>
  </div>
  <ul class="navbar-links">
    <li><a href="#sobre"><i class="fas fa-leaf"></i> Sobre</a></li>
    <li><a href="#cardapio"><i class="fas fa-book-open"></i> Cardápio</a></li>
    <li><a href="#horarios"><i class="fas fa-clock"></i> Horários</a></li>
    <li><a href="#galeria"><i class="fas fa-images"></i> Galeria</a></li>
    <li><a href="#contato"><i class="fas fa-map-pin"></i> Contato</a></li>
  </ul>
  <div class="navbar-actions">
    <button class="theme-toggle" onclick="toggleTheme()" title="Alternar tema">
      <i class="fas fa-moon" id="themeIcon"></i>
    </button>
    <button class="hamburger" onclick="toggleMenu()" aria-label="Menu">
      <span></span><span></span><span></span>
    </button>
  </div>
</nav>

<!-- MOBILE MENU -->
<div class="mobile-menu" id="mobileMenu">
  <a href="#sobre" onclick="closeMenu()"><i class="fas fa-leaf"></i> Sobre</a>
  <a href="#cardapio" onclick="closeMenu()"><i class="fas fa-book-open"></i> Cardápio</a>
  <a href="#horarios" onclick="closeMenu()"><i class="fas fa-clock"></i> Horários</a>
  <a href="#galeria" onclick="closeMenu()"><i class="fas fa-images"></i> Galeria</a>
  <a href="#contato" onclick="closeMenu()"><i class="fas fa-map-pin"></i> Contato</a>
</div>

<!-- HERO -->
<section class="hero" id="inicio">
  <div class="hero-content">
    <div class="hero-badge"><i class="fas fa-star"></i> Avaliação 4,4 ★★★★☆ no Google</div>
    <h1>Bisa <span>Cafés</span><br/>Especiais</h1>
    <p>Cada xícara conta uma história. Venha descobrir o universo dos cafés de origem em Apucarana, PR.</p>
    <div class="hero-cta">
      <a href="#cardapio" class="btn-primary"><i class="fas fa-book-open"></i> Ver Cardápio</a>
      <a href="#contato" class="btn-outline"><i class="fas fa-map-pin"></i> Como Chegar</a>
    </div>
  </div>
  <div class="hero-scroll">
    <span>Role para baixo</span>
    <i class="fas fa-chevron-down"></i>
  </div>
</section>

<!-- STATUS BAR -->
<div class="status-bar" id="statusBar">
  <div class="status-indicator">
    <div class="status-dot" id="statusDot"></div>
    <span class="status-text" id="statusText"></span>
  </div>
  <div class="status-info">
    <i class="fas fa-clock"></i>
    <span id="statusDetail"></span>
  </div>
  <div class="status-info">
    <i class="fas fa-calendar-day"></i>
    <span id="currentDay"></span>
  </div>
  <div class="status-clock" id="liveClock"></div>
</div>

<!-- SOBRE -->
<section id="sobre">
  <div class="section-inner">
    <div class="about-grid">
      <div class="about-image-wrapper">
        <img
          src="https://images.unsplash.com/photo-1442512595331-e89e73853f31?w=900&q=80"
          alt="Interior da Bisa Cafés Especiais"
          class="about-image"
        />
        <div class="about-image-badge">
          <div class="number">4,4</div>
          <div class="label">★ Google<br/>Reviews</div>
        </div>
      </div>
      <div>
        <p class="section-label">Nossa história</p>
        <h2 class="section-title">O café do jeito que deve ser</h2>
        <div class="divider"></div>
        <p style="color:var(--text-muted); margin-bottom:1rem; line-height:1.8;">
          A Bisa Cafés Especiais nasceu da paixão pelo grão perfeito e pelo prazer de compartilhar momentos únicos. Localizada no coração de Apucarana, no Paraná, nossa cafeteria é um refúgio para quem aprecia o café de verdade — cultivado com cuidado, preparado com técnica e servido com carinho.
        </p>
        <p style="color:var(--text-muted); margin-bottom:2rem; line-height:1.8;">
          Trabalhamos com grãos selecionados de origens especiais, utilizando métodos de extração que valorizam as notas aromáticas e o sabor único de cada blend. Além do café, nossa cozinha oferece opções deliciosas para acompanhar cada momento do seu dia.
        </p>
        <div class="about-features">
          <div class="about-feature">
            <div class="about-feature-icon"><i class="fas fa-seedling"></i></div>
            <div>
              <h4>Grãos Selecionados</h4>
              <p>Origens especiais cuidadosamente escolhidas</p>
            </div>
          </div>
          <div class="about-feature">
            <div class="about-feature-icon"><i class="fas fa-fire"></i></div>
            <div>
              <h4>Torras Artesanais</h4>
              <p>Torra personalizada para cada perfil</p>
            </div>
          </div>
          <div class="about-feature">
            <div class="about-feature-icon"><i class="fas fa-award"></i></div>
            <div>
              <h4>Baristas Treinados</h4>
              <p>Profissionais apaixonados pelo café</p>
            </div>
          </div>
          <div class="about-feature">
            <div class="about-feature-icon"><i class="fas fa-heart"></i></div>
            <div>
              <h4>Ambiente Acolhedor</h4>
              <p>Um espaço que convida ao relaxar</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- CARDÁPIO -->
<section id="cardapio" class="menu-section">
  <div class="section-inner">
    <p class="section-label">O que temos</p>
    <h2 class="section-title">Nosso Cardápio</h2>
    <div class="divider"></div>
    <p class="section-subtitle">Do clássico espresso ao cold brew artesanal — e acompanhamentos que combinam perfeitamente.</p>

    <!-- Tabs -->
    <div class="menu-tabs">
      <button class="menu-tab active" onclick="switchTab('cafes', this)"><i class="fas fa-mug-hot"></i> Cafés</button>
      <button class="menu-tab" onclick="switchTab('especiais', this)"><i class="fas fa-star"></i> Especiais</button>
      <button class="menu-tab" onclick="switchTab('frios', this)"><i class="fas fa-snowflake"></i> Gelados</button>
      <button class="menu-tab" onclick="switchTab('cha', this)"><i class="fas fa-leaf"></i> Chás & Outros</button>
      <button class="menu-tab" onclick="switchTab('doces', this)"><i class="fas fa-cookie-bite"></i> Doces & Salgados</button>
    </div>

    <!-- Cafés Quentes -->
    <div class="menu-grid">
      <div class="menu-category active" id="tab-cafes">

        <div class="menu-card">
          <div class="menu-card-img" style="background:#3e1f10; display:flex; align-items:center; justify-content:center; font-size:3.5rem;">☕</div>
          <div class="menu-card-body">
            <span class="menu-card-tag">Clássico</span>
            <h3>Espresso Simples</h3>
            <p>Extração perfeita com grãos de origem especial. Encorpado, com crema dourada e aroma inconfundível.</p>
            <div class="menu-card-footer">
              <span class="menu-price">R$ 7,00</span>
            </div>
          </div>
        </div>

        <div class="menu-card">
          <div class="menu-card-img" style="background:#5c3317; display:flex; align-items:center; justify-content:center; font-size:3.5rem;">☕</div>
          <div class="menu-card-body">
            <span class="menu-card-tag">Clássico</span>
            <h3>Espresso Duplo</h3>
            <p>Dose dupla para os que apreciam mais intensidade e sabor concentrado do bom café especial.</p>
            <div class="menu-card-footer">
              <span class="menu-price">R$ 10,00</span>
            </div>
          </div>
        </div>

        <div class="menu-card">
          <div class="menu-card-img" style="background:#8b5e3c; display:flex; align-items:center; justify-content:center; font-size:3.5rem;">🥛</div>
          <div class="menu-card-body">
            <span class="menu-card-tag">Popular</span>
            <h3>Cappuccino Artesanal</h3>
            <p>Espresso encorpado com leite vaporizado e microespuma cremosa. Polvilhado com cacau premium.</p>
            <div class="menu-card-footer">
              <span class="menu-price">R$ 14,00</span>
              <span class="menu-badge">⭐ Favorito</span>
            </div>
          </div>
        </div>

        <div class="menu-card">
          <div class="menu-card-img" style="background:#6b4226; display:flex; align-items:center; justify-content:center; font-size:3.5rem;">☕</div>
          <div class="menu-card-body">
            <span class="menu-card-tag">Tradicional</span>
            <h3>Café com Leite</h3>
            <p>A combinação clássica: espresso suave e leite integral quentinho, ideal para o café da manhã.</p>
            <div class="menu-card-footer">
              <span class="menu-price">R$ 12,00</span>
            </div>
          </div>
        </div>

        <div class="menu-card">
          <div class="menu-card-img" style="background:#4a2c1a; display:flex; align-items:center; justify-content:center; font-size:3.5rem;">☕</div>
          <div class="menu-card-body">
            <span class="menu-card-tag">Filtrado</span>
            <h3>Coado Especial V60</h3>
            <p>Método de coado japonês que realça as notas florais e frutadas do grão. Servido em dose generosa.</p>
            <div class="menu-card-footer">
              <span class="menu-price">R$ 15,00</span>
            </div>
          </div>
        </div>

        <div class="menu-card">
          <div class="menu-card-img" style="background:#7b4226; display:flex; align-items:center; justify-content:center; font-size:3.5rem;">☕</div>
          <div class="menu-card-body">
            <span class="menu-card-tag">Coado</span>
            <h3>Americano Especial</h3>
            <p>Espresso diluído em água quente, mantendo o sabor suave mas com toda a qualidade do grão especial.</p>
            <div class="menu-card-footer">
              <span class="menu-price">R$ 11,00</span>
            </div>
          </div>
        </div>

      </div>

      <!-- Especiais -->
      <div class="menu-category" id="tab-especiais">

        <div class="menu-card">
          <div class="menu-card-img" style="background:#3e1f10; display:flex; align-items:center; justify-content:center; font-size:3.5rem;">✨</div>
          <div class="menu-card-body">
            <span class="menu-card-tag">Assinatura</span>
            <h3>Bisa Especial</h3>
            <p>Nossa criação exclusiva: espresso, leite condensado artesanal, canela e um toque de baunilha. Uma experiência única.</p>
            <div class="menu-card-footer">
              <span class="menu-price">R$ 18,00</span>
              <span class="menu-badge">🏆 Exclusivo</span>
            </div>
          </div>
        </div>

        <div class="menu-card">
          <div class="menu-card-img" style="background:#5c2d00; display:flex; align-items:center; justify-content:center; font-size:3.5rem;">🍫</div>
          <div class="menu-card-body">
            <span class="menu-card-tag">Assinatura</span>
            <h3>Mocha Premium</h3>
            <p>Espresso, chocolate belga 70%, leite vaporizado e chantilly artesanal. Para os amantes de chocolate e café.</p>
            <div class="menu-card-footer">
              <span class="menu-price">R$ 17,00</span>
              <span class="menu-badge">⭐ Favorito</span>
            </div>
          </div>
        </div>

        <div class="menu-card">
          <div class="menu-card-img" style="background:#6b4226; display:flex; align-items:center; justify-content:center; font-size:3.5rem;">🌿</div>
          <div class="menu-card-body">
            <span class="menu-card-tag">Especial</span>
            <h3>Latte de Caramelo</h3>
            <p>Espresso suave com leite cremoso e calda de caramelo artesanal. Doce equilíbrio de sabores.</p>
            <div class="menu-card-footer">
              <span class="menu-price">R$ 16,00</span>
            </div>
          </div>
        </div>

        <div class="menu-card">
          <div class="menu-card-img" style="background:#4a2c1a; display:flex; align-items:center; justify-content:center; font-size:3.5rem;">🫖</div>
          <div class="menu-card-body">
            <span class="menu-card-tag">Especial</span>
            <h3>Flat White</h3>
            <p>Duplo ristretto com microespuma sedosa de leite integral. Café intenso com cremosidade incomparável.</p>
            <div class="menu-card-footer">
              <span class="menu-price">R$ 16,00</span>
            </div>
          </div>
        </div>

      </div>

      <!-- Gelados -->
      <div class="menu-category" id="tab-frios">

        <div class="menu-card">
          <div class="menu-card-img" style="background:#1a4a5c; display:flex; align-items:center; justify-content:center; font-size:3.5rem;">🧊</div>
          <div class="menu-card-body">
            <span class="menu-card-tag">Cold Brew</span>
            <h3>Cold Brew Artesanal</h3>
            <p>Café extraído a frio por 18 horas. Sabor suave, baixa acidez e notas de chocolate amargo. Refrescante!</p>
            <div class="menu-card-footer">
              <span class="menu-price">R$ 16,00</span>
              <span class="menu-badge">🧊 Gelado</span>
            </div>
          </div>
        </div>

        <div class="menu-card">
          <div class="menu-card-img" style="background:#2c3e50; display:flex; align-items:center; justify-content:center; font-size:3.5rem;">🥤</div>
          <div class="menu-card-body">
            <span class="menu-card-tag">Gelado</span>
            <h3>Iced Latte</h3>
            <p>Espresso gelado com leite integral e gelo. Perfeito para os dias quentes de Apucarana!</p>
            <div class="menu-card-footer">
              <span class="menu-price">R$ 14,00</span>
            </div>
          </div>
        </div>

        <div class="menu-card">
          <div class="menu-card-img" style="background:#1a2c3e; display:flex; align-items:center; justify-content:center; font-size:3.5rem;">🧋</div>
          <div class="menu-card-body">
            <span class="menu-card-tag">Especial</span>
            <h3>Frappuccino Bisa</h3>
            <p>Café gelado batido com leite, gelo e calda de chocolate. Finalizado com chantilly e granulado.</p>
            <div class="menu-card-footer">
              <span class="menu-price">R$ 19,00</span>
              <span class="menu-badge">⭐ Favorito</span>
            </div>
          </div>
        </div>

        <div class="menu-card">
          <div class="menu-card-img" style="background:#3e2c1a; display:flex; align-items:center; justify-content:center; font-size:3.5rem;">🍵</div>
          <div class="menu-card-body">
            <span class="menu-card-tag">Gelado</span>
            <h3>Cold Brew + Leite</h3>
            <p>Cold brew artesanal com leite condensado e gelo. Doce e refrescante ao mesmo tempo.</p>
            <div class="menu-card-footer">
              <span class="menu-price">R$ 18,00</span>
            </div>
          </div>
        </div>

      </div>

      <!-- Chás & Outros -->
      <div class="menu-category" id="tab-cha">

        <div class="menu-card">
          <div class="menu-card-img" style="background:#2d4a1a; display:flex; align-items:center; justify-content:center; font-size:3.5rem;">🍃</div>
          <div class="menu-card-body">
            <span class="menu-card-tag">Chá</span>
            <h3>Chá Verde Matcha</h3>
            <p>Matcha premium japonês preparado com leite vaporizado ou água quente. Suave e revigorante.</p>
            <div class="menu-card-footer">
              <span class="menu-price">R$ 14,00</span>
            </div>
          </div>
        </div>

        <div class="menu-card">
          <div class="menu-card-img" style="background:#4a1a1a; display:flex; align-items:center; justify-content:center; font-size:3.5rem;">🫖</div>
          <div class="menu-card-body">
            <span class="menu-card-tag">Chá</span>
            <h3>Chai Latte</h3>
            <p>Blend de especiarias indianas com leite vaporizado e mel. Canela, cardamomo e gengibre.</p>
            <div class="menu-card-footer">
              <span class="menu-price">R$ 15,00</span>
            </div>
          </div>
        </div>

        <div class="menu-card">
          <div class="menu-card-img" style="background:#3a1a2c; display:flex; align-items:center; justify-content:center; font-size:3.5rem;">🧃</div>
          <div class="menu-card-body">
            <span class="menu-card-tag">Natural</span>
            <h3>Suco Natural</h3>
            <p>Frutas frescas da estação. Laranja, limão, maracujá ou abacaxi com hortelã. Consulte disponibilidade.</p>
            <div class="menu-card-footer">
              <span class="menu-price">R$ 12,00</span>
            </div>
          </div>
        </div>

        <div class="menu-card">
          <div class="menu-card-img" style="background:#2a3a1a; display:flex; align-items:center; justify-content:center; font-size:3.5rem;">🌿</div>
          <div class="menu-card-body">
            <span class="menu-card-tag">Chá</span>
            <h3>Chá de Ervas</h3>
            <p>Seleção de chás naturais: camomila, hortelã, erva-cidreira e hibisco. Relaxante e aromático.</p>
            <div class="menu-card-footer">
              <span class="menu-price">R$ 10,00</span>
            </div>
          </div>
        </div>

      </div>

      <!-- Doces & Salgados -->
      <div class="menu-category" id="tab-doces">

        <div class="menu-card">
          <div class="menu-card-img" style="background:#3e2810; display:flex; align-items:center; justify-content:center; font-size:3.5rem;">🥐</div>
          <div class="menu-card-body">
            <span class="menu-card-tag">Confeitaria</span>
            <h3>Croissant de Manteiga</h3>
            <p>Croissant artesanal folhado, crocante por fora e macio por dentro. Perfeito com espresso.</p>
            <div class="menu-card-footer">
              <span class="menu-price">R$ 12,00</span>
              <span class="menu-badge">🥐 Fresco</span>
            </div>
          </div>
        </div>

        <div class="menu-card">
          <div class="menu-card-img" style="background:#5c3010; display:flex; align-items:center; justify-content:center; font-size:3.5rem;">🍰</div>
          <div class="menu-card-body">
            <span class="menu-card-tag">Sobremesa</span>
            <h3>Brownie de Chocolate</h3>
            <p>Brownie denso com chocolate 70% cacau, levemente crocante por fora e úmido por dentro. Com sorvete.</p>
            <div class="menu-card-footer">
              <span class="menu-price">R$ 16,00</span>
              <span class="menu-badge">⭐ Favorito</span>
            </div>
          </div>
        </div>

        <div class="menu-card">
          <div class="menu-card-img" style="background:#4a2c1a; display:flex; align-items:center; justify-content:center; font-size:3.5rem;">🫙</div>
          <div class="menu-card-body">
            <span class="menu-card-tag">Confeitaria</span>
            <h3>Cheesecake de Frutas</h3>
            <p>Cheesecake cremoso com base de biscoito e cobertura de frutos vermelhos frescos da estação.</p>
            <div class="menu-card-footer">
              <span class="menu-price">R$ 18,00</span>
            </div>
          </div>
        </div>

        <div class="menu-card">
          <div class="menu-card-img" style="background:#3e2010; display:flex; align-items:center; justify-content:center; font-size:3.5rem;">🥪</div>
          <div class="menu-card-body">
            <span class="menu-card-tag">Salgado</span>
            <h3>Sanduíche Especial</h3>
            <p>Pão artesanal, queijo prato, peito de peru defumado, rúcula e molho especial da Bisa. Servido quente.</p>
            <div class="menu-card-footer">
              <span class="menu-price">R$ 22,00</span>
            </div>
          </div>
        </div>

        <div class="menu-card">
          <div class="menu-card-img" style="background:#6b4010; display:flex; align-items:center; justify-content:center; font-size:3.5rem;">🧇</div>
          <div class="menu-card-body">
            <span class="menu-card-tag">Café da Manhã</span>
            <h3>Waffle Artesanal</h3>
            <p>Waffle crocante com mel, geleia de frutas vermelhas ou Nutella. Serve 1 pessoa.</p>
            <div class="menu-card-footer">
              <span class="menu-price">R$ 20,00</span>
            </div>
          </div>
        </div>

        <div class="menu-card">
          <div class="menu-card-img" style="background:#5c2810; display:flex; align-items:center; justify-content:center; font-size:3.5rem;">🍩</div>
          <div class="menu-card-body">
            <span class="menu-card-tag">Confeitaria</span>
            <h3>Pão de Mel</h3>
            <p>Pão de mel caseiro coberto com chocolate ao leite. Receita especial com especiarias.</p>
            <div class="menu-card-footer">
              <span class="menu-price">R$ 9,00</span>
            </div>
          </div>
        </div>

      </div>
    </div><!-- /menu-grid -->

    <p style="text-align:center; margin-top:2rem; color:var(--text-muted); font-size:0.85rem;">
      <i class="fas fa-info-circle"></i> Preços e disponibilidade podem variar. Consulte nossa equipe para o cardápio completo do dia.
    </p>
  </div>
</section>

<!-- HORÁRIOS -->
<section id="horarios">
  <div class="section-inner">
    <p class="section-label">Quando estamos aqui</p>
    <h2 class="section-title">Horários de Atendimento</h2>
    <div class="divider"></div>
    <p class="section-subtitle">Confira nosso horário de funcionamento — atualizado em tempo real.</p>

    <div class="hours-grid">
      <div class="hours-table">
        <div class="hours-table-header">
          <i class="fas fa-clock"></i>
          Horário de Funcionamento
        </div>
        <div class="hours-row" id="row-seg">
          <span class="hours-day">Segunda-feira</span>
          <span class="hours-closed">Fechado</span>
        </div>
        <div class="hours-row" id="row-ter">
          <span class="hours-day">Terça-feira</span>
          <span class="hours-time">08:00 – 18:00</span>
        </div>
        <div class="hours-row" id="row-qua">
          <span class="hours-day">Quarta-feira</span>
          <span class="hours-time">08:00 – 18:00</span>
        </div>
        <div class="hours-row" id="row-qui">
          <span class="hours-day">Quinta-feira</span>
          <span class="hours-time">08:00 – 18:00</span>
        </div>
        <div class="hours-row" id="row-sex">
          <span class="hours-day">Sexta-feira</span>
          <span class="hours-time">08:00 – 19:00</span>
        </div>
        <div class="hours-row" id="row-sab">
          <span class="hours-day">Sábado</span>
          <span class="hours-time">08:00 – 14:00</span>
        </div>
        <div class="hours-row" id="row-dom">
          <span class="hours-day">Domingo</span>
          <span class="hours-closed">Fechado</span>
        </div>
      </div>

      <div class="hours-info-cards">
        <div class="hours-info-card">
          <div class="hours-info-icon"><i class="fas fa-map-marker-alt"></i></div>
          <div>
            <h4>Endereço</h4>
            <p>Rua Dr. Munhoz da Rocha, 1339<br/>Apucarana – PR, CEP 86800-012</p>
          </div>
        </div>
        <div class="hours-info-card">
          <div class="hours-info-icon"><i class="fas fa-phone"></i></div>
          <div>
            <h4>Telefone</h4>
            <p><a href="tel:+554331222002">(43) 3122-2002</a></p>
          </div>
        </div>
        <div class="hours-info-card">
          <div class="hours-info-icon"><i class="fab fa-facebook"></i></div>
          <div>
            <h4>Redes Sociais</h4>
            <p>
              <a href="https://www.facebook.com/bisacafesespeciais" target="_blank">
                /bisacafesespeciais
              </a> no Facebook
            </p>
          </div>
        </div>
        <div class="hours-info-card">
          <div class="hours-info-icon"><i class="fas fa-parking"></i></div>
          <div>
            <h4>Estacionamento</h4>
            <p>Estacionamento disponível na rua e proximidades. Fácil acesso de carro e a pé.</p>
          </div>
        </div>
        <div class="hours-info-card">
          <div class="hours-info-icon"><i class="fas fa-credit-card"></i></div>
          <div>
            <h4>Formas de Pagamento</h4>
            <p>Cartão de débito e crédito, Pix e dinheiro. Parcelamos em até 3x sem juros.</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- GALERIA -->
<section id="galeria" style="background:var(--bg-secondary);">
  <div class="section-inner">
    <p class="section-label">Nosso espaço</p>
    <h2 class="section-title">Galeria</h2>
    <div class="divider"></div>
    <p class="section-subtitle">Um ambiente pensado para você se sentir em casa.</p>

    <div class="gallery-grid">
      <div class="gallery-item">
        <img src="https://images.unsplash.com/photo-1509042239860-f550ce710b93?w=800&q=80" alt="Barista preparando café" />
        <div class="gallery-overlay"><span>Arte do barista</span></div>
      </div>
      <div class="gallery-item">
        <img src="https://images.unsplash.com/photo-1554118811-1e0d58224f24?w=600&q=80" alt="Ambiente da cafeteria" />
        <div class="gallery-overlay"><span>Nosso ambiente</span></div>
      </div>
      <div class="gallery-item">
        <img src="https://images.unsplash.com/photo-1600093463592-8e36ae95ef56?w=600&q=80" alt="Cappuccino artesanal" />
        <div class="gallery-overlay"><span>Cappuccino artesanal</span></div>
      </div>
      <div class="gallery-item">
        <img src="https://images.unsplash.com/photo-1497935586351-b67a49e012bf?w=600&q=80" alt="Grãos de café especial" />
        <div class="gallery-overlay"><span>Grãos selecionados</span></div>
      </div>
      <div class="gallery-item">
        <img src="https://images.unsplash.com/photo-1567521464027-f127ff144326?w=600&q=80" alt="Latte art" />
        <div class="gallery-overlay"><span>Latte art</span></div>
      </div>
    </div>
  </div>
</section>

<!-- CONTATO -->
<section id="contato" class="contact-section">
  <div class="section-inner">
    <p class="section-label">Nos encontre</p>
    <h2 class="section-title">Como Chegar</h2>
    <div class="divider"></div>
    <p class="section-subtitle">Estamos esperando por você em Apucarana, PR.</p>

    <div class="contact-grid">
      <div class="contact-info">
        <div class="contact-item">
          <div class="contact-icon"><i class="fas fa-map-marker-alt"></i></div>
          <div>
            <h4>Endereço Completo</h4>
            <p>Rua Dr. Munhoz da Rocha, 1339<br/>Apucarana – PR, CEP 86800-012</p>
          </div>
        </div>
        <div class="contact-item">
          <div class="contact-icon"><i class="fas fa-phone-alt"></i></div>
          <div>
            <h4>Telefone</h4>
            <p><a href="tel:+554331222002">(43) 3122-2002</a></p>
          </div>
        </div>
        <div class="contact-item">
          <div class="contact-icon"><i class="fas fa-clock"></i></div>
          <div>
            <h4>Horário Principal</h4>
            <p>Ter a Sex: 08h às 18h (19h nas sextas)<br/>Sábado: 08h às 14h<br/>Dom e Seg: Fechado</p>
          </div>
        </div>
        <div class="contact-item">
          <div class="contact-icon"><i class="fab fa-facebook"></i></div>
          <div>
            <h4>Facebook</h4>
            <p><a href="https://www.facebook.com/bisacafesespeciais" target="_blank">facebook.com/bisacafesespeciais</a></p>
          </div>
        </div>
        <a href="https://maps.google.com/?q=Rua+Dr.+Munhoz+da+Rocha+1339+Apucarana+PR" target="_blank" class="map-cta">
          <i class="fas fa-directions"></i> Abrir no Google Maps
        </a>
      </div>

      <div class="map-container">
        <iframe
          src="https://maps.google.com/maps?q=Rua+Dr.+Munhoz+da+Rocha+1339,+Apucarana,+PR&output=embed&z=16"
          allowfullscreen loading="lazy"
          referrerpolicy="no-referrer-when-downgrade"
        ></iframe>
      </div>
    </div>
  </div>
</section>

<!-- SOCIAL BANNER -->
<div class="social-banner">
  <h2>Siga a Bisa nas Redes</h2>
  <p>Fique por dentro das novidades, promoções e novos blends</p>
  <div class="social-links">
    <a href="https://www.facebook.com/bisacafesespeciais" target="_blank" class="social-link">
      <i class="fab fa-facebook"></i> Facebook
    </a>
    <a href="tel:+554331222002" class="social-link">
      <i class="fas fa-phone"></i> (43) 3122-2002
    </a>
    <a href="https://maps.google.com/?q=Rua+Dr.+Munhoz+da+Rocha+1339+Apucarana+PR" target="_blank" class="social-link">
      <i class="fas fa-map-pin"></i> Nos encontre no mapa
    </a>
  </div>
</div>

<!-- FOOTER -->
<footer>
  <div class="footer-inner">
    <div>
      <div class="footer-brand">Bisa <span>Cafés</span> Especiais</div>
      <div style="font-size:0.78rem; margin-top:4px; opacity:0.6;">Apucarana, Paraná – Brasil</div>
    </div>
    <div class="footer-copy">
      © 2025 Bisa Cafés Especiais · Todos os direitos reservados
    </div>
    <div class="footer-links">
      <a href="#sobre">Sobre</a>
      <a href="#cardapio">Cardápio</a>
      <a href="#contato">Contato</a>
    </div>
  </div>
</footer>

<!-- FLOATING WHATSAPP -->
<a href="tel:+554331222002" class="whatsapp-float" title="Ligar agora">
  <i class="fas fa-phone"></i>
</a>

<script>
// ===== THEME TOGGLE =====
function toggleTheme() {
  const html = document.documentElement;
  const icon = document.getElementById('themeIcon');
  if (html.getAttribute('data-theme') === 'dark') {
    html.removeAttribute('data-theme');
    icon.className = 'fas fa-moon';
    localStorage.setItem('theme', 'light');
  } else {
    html.setAttribute('data-theme', 'dark');
    icon.className = 'fas fa-sun';
    localStorage.setItem('theme', 'dark');
  }
}
(function() {
  const saved = localStorage.getItem('theme');
  const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  if (saved === 'dark' || (!saved && prefersDark)) {
    document.documentElement.setAttribute('data-theme', 'dark');
    const icon = document.getElementById('themeIcon');
    if (icon) icon.className = 'fas fa-sun';
  }
})();

// ===== MOBILE MENU =====
function toggleMenu() {
  document.getElementById('mobileMenu').classList.toggle('open');
}
function closeMenu() {
  document.getElementById('mobileMenu').classList.remove('open');
}

// ===== MENU TABS =====
function switchTab(tab, btn) {
  document.querySelectorAll('.menu-category').forEach(el => el.classList.remove('active'));
  document.querySelectorAll('.menu-tab').forEach(el => el.classList.remove('active'));
  document.getElementById('tab-' + tab).classList.add('active');
  btn.classList.add('active');
}

// ===== REAL-TIME STATUS + CLOCK =====
const schedule = {
  0: null,                      // Sunday — closed
  1: null,                      // Monday — closed
  2: { open: [8,0], close: [18,0] },
  3: { open: [8,0], close: [18,0] },
  4: { open: [8,0], close: [18,0] },
  5: { open: [8,0], close: [19,0] },
  6: { open: [8,0], close: [14,0] },
};

const dayNames = ['Domingo','Segunda-feira','Terça-feira','Quarta-feira','Quinta-feira','Sexta-feira','Sábado'];
const dayShort = ['dom','seg','ter','qua','qui','sex','sab'];
const rowIds   = ['row-dom','row-seg','row-ter','row-qua','row-qui','row-sex','row-sab'];

function toMin(h, m) { return h * 60 + m; }

function getStatus(now) {
  const day = now.getDay();
  const currentMin = toMin(now.getHours(), now.getMinutes());
  const todaySchedule = schedule[day];

  // Check today
  if (todaySchedule) {
    const openMin  = toMin(todaySchedule.open[0],  todaySchedule.open[1]);
    const closeMin = toMin(todaySchedule.close[0], todaySchedule.close[1]);
    const soonnMin = openMin - 30;

    if (currentMin >= openMin && currentMin < closeMin) {
      const minsLeft = closeMin - currentMin;
      if (minsLeft <= 30) {
        return { state: 'soon', label: 'Fechando em breve', detail: 'Fecha às ' + fmtTime(todaySchedule.close) };
      }
      return { state: 'open', label: 'Aberto agora', detail: 'Fecha hoje às ' + fmtTime(todaySchedule.close) };
    }
    if (currentMin >= soonnMin && currentMin < openMin) {
      return { state: 'soon', label: 'Abrindo em breve', detail: 'Abre às ' + fmtTime(todaySchedule.open) };
    }
    if (currentMin >= closeMin) {
      // find next day
      return { state: 'closed', label: 'Fechado agora', detail: 'Fechou hoje às ' + fmtTime(todaySchedule.close) + getNextOpen(day) };
    }
    // before open
    return { state: 'closed', label: 'Fechado', detail: 'Abre hoje às ' + fmtTime(todaySchedule.open) };
  }
  return { state: 'closed', label: 'Fechado hoje', detail: getNextOpen(day).trim() };
}

function getNextOpen(day) {
  for (let i = 1; i <= 7; i++) {
    const nextDay = (day + i) % 7;
    if (schedule[nextDay]) {
      return ' · Próxima abertura: ' + dayNames[nextDay] + ' às ' + fmtTime(schedule[nextDay].open);
    }
  }
  return '';
}

function fmtTime(arr) {
  return String(arr[0]).padStart(2,'0') + 'h' + (arr[1] ? String(arr[1]).padStart(2,'0') : '00');
}

function updateStatus() {
  const now = new Date();
  const status = getStatus(now);
  const dot  = document.getElementById('statusDot');
  const text = document.getElementById('statusText');
  const detail = document.getElementById('statusDetail');
  const dayEl = document.getElementById('currentDay');
  const clock = document.getElementById('liveClock');

  dot.className   = 'status-dot ' + status.state;
  text.className  = 'status-text ' + status.state;
  text.textContent = status.label;
  detail.textContent = status.detail;
  dayEl.textContent = dayNames[now.getDay()];

  const hh = String(now.getHours()).padStart(2,'0');
  const mm = String(now.getMinutes()).padStart(2,'0');
  const ss = String(now.getSeconds()).padStart(2,'0');
  clock.textContent = hh + ':' + mm + ':' + ss;

  // Highlight today in table
  const todayIdx = now.getDay();
  rowIds.forEach((id, idx) => {
    const row = document.getElementById(id);
    if (!row) return;
    row.classList.remove('today');
    // Remove old today badge
    row.querySelectorAll('.today-badge').forEach(b => b.remove());
    if (idx === todayIdx) {
      row.classList.add('today');
      const badge = document.createElement('span');
      badge.className = 'today-badge';
      badge.textContent = 'Hoje';
      row.querySelector('.hours-day').appendChild(badge);
    }
  });
}

updateStatus();
setInterval(updateStatus, 1000);

// ===== SMOOTH SCROLL OFFSET FOR FIXED NAV =====
document.querySelectorAll('a[href^="#"]').forEach(a => {
  a.addEventListener('click', e => {
    const target = document.querySelector(a.getAttribute('href'));
    if (target) {
      e.preventDefault();
      const top = target.getBoundingClientRect().top + window.scrollY - 80;
      window.scrollTo({ top, behavior: 'smooth' });
    }
  });
});
</script>
</body>
</html>`)
})

export default app
